package pa;

public class test_p8 {

	public static void main(String[] args) {
		Car car1;
		car1=new Car();
		car1.show();

	}

}
